module.exports = {
  BOT_TOKEN: "7551772302:AAEEyDXgoj90KCdvlV3g7U-27wE1Sa_XcVU", 
  OWNER_ID: "6878949999", 
};

